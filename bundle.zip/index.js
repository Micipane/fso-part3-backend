const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const app = express()

app.use(express.json())
app.use(cors())
app.use(express.static('dist'))

const postToken = morgan.token(
    'head',
    (request, response) => { return JSON.stringify(request.body) }
)

app.use(morgan(':method :url :status :res[content-length] - :response-time ms :head'))

let persons = [
    { 
      id: "1",
      name: "Arto Hellas", 
      number: "040-123456"
    },
    { 
      id: "2",
      name: "Ada Lovelace", 
      number: "39-44-5323523"
    },
    { 
      id: "3",
      name: "Dan Abramov", 
      number: "12-43-234345"
    },
    { 
      id: "4",
      name: "Mary Poppendieck", 
      number: "39-23-6423122"
    }
]

app.get('/api/persons', (request, response) => {
    response.json(persons)
})

app.get('/info', (request, response) => {
    const current_time = new Date()

    response.send(`<div><p>Phonebook has info for ${persons.length} people</p><p>${current_time}</p></div>`)
})

app.get('/api/persons/:id', (request, response) => {
    const id = request.params.id
    const person = persons.find(person => person.id === id)

    if (person) {
        response.json(person)
    } else {
        response.status(404).end()
    }
    
})

const generateId = () => {
    const min = 1
    const max = 100000000

    return Math.floor(Math.random() * (max - min + 1) + min).toString()
}

app.post('/api/persons', (request, response) => {
    const person = request.body

    if (!person || !person.name || !person.number) {
        return response.status(400).json({
            error: "name or number doesn't exist"
        })
    }

    if (persons.find(p => p.name === person.name)) {
        return response.status(400).json({
            error: "name must be unique"
        })
    }

    const new_person = {
        id: generateId(),
        name: person.name,
        number: person.number
    }

    persons = persons.concat(new_person)

    response.json(new_person)
})


app.delete('/api/persons/:id', (request, response) => {
    const id = request.params.id
    persons = persons.filter(person => person.id !== id)

    response.status(204).end()
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
})
